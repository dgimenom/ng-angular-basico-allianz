import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'noWhitespace'
})
export class NoWhitespacePipe implements PipeTransform {
  transform(value: string) {
    return value.replace(/\s/g, '');
  }
}
