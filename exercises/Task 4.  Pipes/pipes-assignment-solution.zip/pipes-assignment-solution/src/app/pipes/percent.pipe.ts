import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'percent'
})
export class PercentPipe implements PipeTransform {
  transform(value: number, percentage: number = 100) {
    const num = value * percentage * 0.01;
    return num + ' %';
  }
}
