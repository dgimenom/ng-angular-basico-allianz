import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';


import { AppComponent } from './app.component';
import { RoundPipe } from './pipes/round.pipe';
import { ReversePipe } from './pipes/reverse.pipe';
import { NoWhitespacePipe } from './pipes/no-whitespace.pipe';
import { PercentPipe } from './pipes/percent.pipe';

// import { registerLocaleData } from '@angular/common';
// import localeFr from '@angular/common/locales/fr';
// import localeFrExtra from '@angular/common/locales/extra/fr';

// registerLocaleData(localeFr, 'fr-FR', localeFrExtra);

@NgModule({
  declarations: [
    AppComponent,
    RoundPipe,
    ReversePipe,
    NoWhitespacePipe,
    PercentPipe
  ],
  imports: [
    BrowserModule,
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
