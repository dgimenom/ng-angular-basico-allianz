import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Recipe } from 'src/app/models/recipe.model';
import { RecipesService } from 'src/app/services/recipes.service';

@Component({
  selector: 'app-recipe',
  templateUrl: './recipe.component.html',
  styleUrls: ['./recipe.component.css']
})
export class RecipeComponent implements OnInit {
  @Input('recipeData') recipe: Recipe;
  newIngredient: string = '';

  constructor(private recipesService: RecipesService) { }

  ngOnInit() {
  }

  getColor() {
    return this.recipe.difficulty === 'easy' ? 'green'
      : this.recipe.difficulty === 'medium' ? 'orange'
      : 'red';
  }

  addIngredient() {
    this.recipe.ingredients.push(this.newIngredient);
    this.recipesService.updateRecipe(this.recipe);
    this.newIngredient = '';
  }

}
