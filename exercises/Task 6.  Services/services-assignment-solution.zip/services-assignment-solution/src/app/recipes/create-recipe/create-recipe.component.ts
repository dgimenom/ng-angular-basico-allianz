import { Component, OnInit } from '@angular/core';
import { Recipe } from 'src/app/models/recipe.model';
import { RecipesService } from 'src/app/services/recipes.service';

@Component({
  selector: 'app-create-recipe',
  templateUrl: './create-recipe.component.html',
  styleUrls: ['./create-recipe.component.css']
})
export class CreateRecipeComponent implements OnInit {
  constructor(private recipesService: RecipesService) { }

  ngOnInit() {
  }

  addRecipe() {
    const newRecipe: Recipe = {
      id: 5,
      name: 'Spaghetti',
      description: 'The dummy pasta!',
      difficulty: 'hard',
      estimatedTime: 60,
      ingredients: ['spaghetti', 'tomato', 'parmesan']
    };
    this.recipesService.addRecipe(newRecipe);
  }

}
