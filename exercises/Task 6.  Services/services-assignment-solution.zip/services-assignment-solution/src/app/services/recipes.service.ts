import { Injectable } from '@angular/core';
import { Recipe } from '../models/recipe.model';

@Injectable({
  providedIn: 'root'
})
export class RecipesService {
  recipes: Recipe[] = [
    {
      id: 0,
      name: 'Pizza',
      description: 'The awesome pizza!',
      difficulty: 'medium',
      estimatedTime: 60,
      ingredients: ['ham', 'tomato', 'mozzarella']
    },
    {
      id: 1,
      name: 'Veggie Burger',
      description: 'The best burger ever!',
      difficulty: 'easy',
      estimatedTime: 30,
      ingredients: ['veggie burger', 'tomato', 'onion']
    }
  ];

  constructor() { }

  addRecipe(recipe: Recipe) {
    this.recipes.push(recipe);
  }

  updateRecipe(recipe: Recipe) {
    const index = this.recipes.findIndex(item => item.id === recipe.id);
    this.recipes[index] = recipe;
  }
}
