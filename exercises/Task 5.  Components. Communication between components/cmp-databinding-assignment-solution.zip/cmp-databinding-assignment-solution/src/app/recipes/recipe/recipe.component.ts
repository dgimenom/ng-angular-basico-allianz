import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Recipe } from 'src/app/models/recipe.model';

@Component({
  selector: 'app-recipe',
  templateUrl: './recipe.component.html',
  styleUrls: ['./recipe.component.css']
})
export class RecipeComponent implements OnInit {
  @Input('recipeData') recipe: Recipe;
  @Output() recipeUpdated = new EventEmitter<Recipe>();
  newIngredient: string = '';

  constructor() { }

  ngOnInit() {
  }

  getColor() {
    return this.recipe.difficulty === 'easy' ? 'green'
      : this.recipe.difficulty === 'medium' ? 'orange'
      : 'red';
  }

  addIngredient() {
    this.recipe.ingredients.push(this.newIngredient);
    this.recipeUpdated.emit(this.recipe);
    this.newIngredient = '';
  }

}
