import { Component, OnInit } from '@angular/core';
import { Recipe } from '../models/recipe.model';

@Component({
  selector: 'app-recipes',
  templateUrl: './recipes.component.html',
  styleUrls: ['./recipes.component.css']
})
export class RecipesComponent implements OnInit {
  recipes: Recipe[];

  constructor() { }

  ngOnInit() {
    this.recipes = [
      {
        id: 0,
        name: 'Pizza',
        description: 'The awesome pizza!',
        difficulty: 'medium',
        estimatedTime: 60,
        ingredients: ['ham', 'tomato', 'mozzarella']
      },
      {
        id: 1,
        name: 'Veggie Burger',
        description: 'The best burger ever!',
        difficulty: 'easy',
        estimatedTime: 30,
        ingredients: ['veggie burger', 'tomato', 'onion']
      }
    ];
  }

  onRecipeUpdated(recipe: Recipe, index: number) {
    this.recipes[index] = recipe;
  }

  onAddRecipe(recipe: Recipe) {
    this.recipes.push(recipe);
  }

}
