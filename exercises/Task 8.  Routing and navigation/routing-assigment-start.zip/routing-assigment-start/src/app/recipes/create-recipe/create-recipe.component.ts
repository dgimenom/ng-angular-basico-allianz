import { Component, OnInit } from '@angular/core';
import { Recipe } from 'src/app/models/recipe.model';
import { RecipesService } from 'src/app/services/recipes.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-create-recipe',
  templateUrl: './create-recipe.component.html',
  styleUrls: ['./create-recipe.component.css']
})
export class CreateRecipeComponent implements OnInit {
  requiredMessage = 'Please, provide a valid value, this field is required!';
  createRecipeForm: FormGroup;
  maxLengthAllowed = 100;
  positiveNumberPattern: any = /^\d*[1-9]\d*$/;
  maxEstimatedTime = 500;

  get name(): FormControl {
    return this.createRecipeForm.get('name') as FormControl;
  }

  get description(): FormControl {
    return this.createRecipeForm.get('description') as FormControl;
  }

  get difficulty(): FormControl {
    return this.createRecipeForm.get('difficulty') as FormControl;
  }

  get estimatedTime(): FormControl {
    return this.createRecipeForm.get('estimatedTime') as FormControl;
  }

  constructor(private recipesService: RecipesService) { }

  ngOnInit() {
    this.buildForm();
  }

  buildForm() {
    this.createRecipeForm = new FormGroup({
      name: new FormControl(null, [
        Validators.required,
        Validators.maxLength(this.maxLengthAllowed)
      ]),
      description: new FormControl(null),
      difficulty: new FormControl(null, [Validators.required]),
      estimatedTime: new FormControl(
        null,
        [Validators.required,
        Validators.pattern(this.positiveNumberPattern),
        this.customNumbersRange.bind(this)])
    });
  }

  submitForm() {
    this.createRecipeForm.markAllAsTouched();
    if (this.createRecipeForm.valid) {
      const newRecipe: Recipe = {
        id: Math.random() * Math.random() * 100,
        name: this.name.value,
        description: this.description.value,
        difficulty: this.difficulty.value,
        estimatedTime: this.estimatedTime.value,
        ingredients: []
      };
      this.recipesService.addRecipe(newRecipe);
      this.createRecipeForm.reset();
    }
  }

  customNumbersRange(control: FormControl): {[s: string]: boolean} {
    if (control.value > this.maxEstimatedTime) {
      return { maxNumberReached: true };
    }
    return null;
  }
}
