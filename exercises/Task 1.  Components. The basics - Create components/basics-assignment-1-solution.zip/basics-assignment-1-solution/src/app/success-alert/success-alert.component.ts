import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-success-alert',
  template: `
    <p>This is a success message!</p>
  `,
  styles: [`
    p {
      background-color: green;
      color: white;
      font-weight: bold;
      margin: 10px;
      padding: 10px;
    }
  `]
})
export class SuccessAlertComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
