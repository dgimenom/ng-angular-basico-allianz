import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  password: string = '1234';
  displayPassword: boolean = false;
  logs = [];

  toggleViewPassword() {
    this.displayPassword = !this.displayPassword;
    this.logs.push(new Date);
  }
}
